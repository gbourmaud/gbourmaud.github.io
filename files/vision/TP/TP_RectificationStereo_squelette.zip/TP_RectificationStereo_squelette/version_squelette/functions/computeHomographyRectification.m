function [Hn1, Hn2] = computeHomographyRectification(K, R21, T21)

R1g = eye(3);
T1g = zeros(3,1);
R2g = R21;
T2g = T21;
[Rn1,Rn2] = rectify(R1g,T1g,R2g,T2g);


Hn1 = K*Rn1*inv(K);
Hn2 = K*Rn2*inv(K);