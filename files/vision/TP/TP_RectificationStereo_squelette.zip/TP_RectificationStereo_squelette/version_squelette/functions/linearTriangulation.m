function  [d, tcr] = linearTriangulation(xr, xc, Rcr, tcr, nbPt)

A_reshaped = [xc(1,:)*tcr(3) - tcr(1); xc(2,:)*tcr(3) - tcr(2)];

H = sum(A_reshaped.^2,1);
invH = 1./H;

b_reshaped = [Rcr(1,:)*xr - xc(1,:).*(Rcr(3,:)*xr); Rcr(2,:)*xr - xc(2,:).*(Rcr(3,:)*xr)];

lambda = invH.*sum(A_reshaped.*b_reshaped,1);

if(median(lambda) < 0)
    lambda = - lambda;
    tcr = -tcr;
end

d = 1./lambda;

end