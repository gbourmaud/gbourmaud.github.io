function [Rcr, Rtcr, disparity, resMin] = GNLineSearchBAPositiveDisparitySparse(Rcr, Rtcr, disparity, xr, xc, nbPt)

xc = xc(1:2,:);%inhomogeneous coordinates

disparity_prior = disparity;

a_t = 0;

for i = 1:15
    disp(['Iteration ' num2str(i)]);
    %compute error and jacobian
    [r_ba, r_dispPrior] = computeError(xc, xr, Rcr, Rtcr, disparity, disparity_prior);
    w_ba = computeWeights(r_ba);
    
    resPrec = computeResidual(r_ba, r_dispPrior, a_t);
    
    [J_ba_rot,J_ba_trans,J_ba_disp_diag] = computeJacobian(nbPt, xr, Rcr, Rtcr, disparity);
    
    [delta_Rcr,delta_Rtcr,delta_disparity] = computeDelta(nbPt,J_ba_rot,J_ba_trans,J_ba_disp_diag, r_ba, w_ba, r_dispPrior, a_t);
    
    [Rcr, Rtcr, disparity, condOut, resMin] = lineSearch(nbPt,delta_Rcr,delta_Rtcr,delta_disparity,Rcr,Rtcr,disparity,xr,xc,disparity_prior,a_t,resPrec);
    
    if(condOut)
        break;
    end
end


end

function [J_ba_rot,J_ba_trans,J_ba_disp_diag] = computeJacobian(nbPt, xr, Rcr, Rtcr, disparity)

G1 = [0 0 0; 0 0 -1; 0 1 0];
G2 = [0 0 1; 0 0 0; -1 0 0];
G3 = [0 -1 0; 1 0 0; 0 0 0];

% J_ba_rot = zeros(nbPt*2,3);
% J_ba_trans = zeros(nbPt*2,2);
% J_ba_disp_diag = zeros(nbPt*2,1);

cross_tcr = HatSO3(Rtcr*[0;0;1]);

cross_tcrG1 = HatSO3(Rtcr*G1*[0;0;1]);
cross_tcrG2 = HatSO3(Rtcr*G2*[0;0;1]);

xr_in_c = Rcr*xr;
% for ii = 1 : nbPt
%     x1 = xr(1,ii);
%     x2 = xr(2,ii);
%     x3 = xr(3,ii);
%     
%     J_ba_proj = [1/x3 0 -x1/(x3^2); 0 1/x3 -x2/(x3^2)];
%     
%     J_ba_rot(1+(ii-1)*2:ii*2,:) = (J_ba_proj + disparity(ii,1)*[0 -1 0; 1 0 0]*cross_tcr) * [G1*xr_in_c(:,ii) G2*xr_in_c(:,ii) G3*xr_in_c(:,ii)];
%     
%     %J_ba_trans(1+(ii-1)*2:ii*2,:) = disparity(ii,1)*[0 -1 0; 1 0 0]*[ cross_tcrG1*xr_in_c(:,ii) cross_tcrG2*xr_in_c(:,ii)];
%     
%     %J_ba_disp_diag(1+(ii-1)*2:ii*2,1) = [0 -1 0; 1 0 0]*cross_tcr*xr_in_c(:,ii);
%     
% end

X1 = xr_in_c(1,:);
X2 = xr_in_c(2,:);
X3 = xr_in_c(3,:);
inv_X3_squared = (1./X3).^2;

J_ba_rot = zeros(nbPt*2,3);
J_ba_rot(1:2:end,1) = -X1.*X2.*inv_X3_squared + disparity'.*([0 -1 0]*cross_tcr*G1*xr_in_c);
J_ba_rot(1:2:end,2) = 1 + (X1.^2).*inv_X3_squared + disparity'.*([0 -1 0]*cross_tcr*G2*xr_in_c);
J_ba_rot(1:2:end,3) = -X2./X3 + disparity'.*([0 -1 0]*cross_tcr*G3*xr_in_c);
J_ba_rot(2:2:end,1) = -1 -(X2.^2).*inv_X3_squared + disparity'.*([1 0 0]*cross_tcr*G1*xr_in_c);
J_ba_rot(2:2:end,2) = X1.*X2.*inv_X3_squared + disparity'.*([1 0 0]*cross_tcr*G2*xr_in_c);
J_ba_rot(2:2:end,3) = X1./X3 + disparity'.*([1 0 0]*cross_tcr*G3*xr_in_c);

J_ba_trans_G1temp = repmat(disparity',2,1).*([0 -1 0; 1 0 0]*cross_tcrG1*xr_in_c);
J_ba_trans_G2temp = repmat(disparity',2,1).*([0 -1 0; 1 0 0]*cross_tcrG2*xr_in_c);

J_ba_trans = [J_ba_trans_G1temp(:) J_ba_trans_G2temp(:)];

J_ba_disp_diag_temp = [0 -1 0; 1 0 0]*cross_tcr*xr_in_c;
J_ba_disp_diag = J_ba_disp_diag_temp(:);
end

function  [r_ba, r_dispPrior] = computeError(xc, xr, Rcr, Rtcr, disparity, disparity_prior)

X_rot = Rcr*xr; 
xc_rot_pred = (X_rot(1:2,:)./repmat(X_rot(3,:),2,1));

xc_disparity = repmat(disparity',2,1).*([0 -1 0; 1 0 0]*HatSO3(Rtcr*[0;0;1])*Rcr*xr);

r_ba = xc - (xc_rot_pred + xc_disparity);

r_dispPrior = disparity_prior - disparity;

end

function [delta_Rcr,delta_Rtcr,delta_disp] = computeDelta(nbPt,J_ba_rot,J_ba_trans,J_ba_disp_diag, r_ba, w_ba, r_dispPrior, a_t)

sqrtW_ba_diag = sqrt(kron(w_ba(:),ones(2,1)));
J_ba_disp_diag_norm = sqrtW_ba_diag.*J_ba_disp_diag;
J_ba_motion_norm = kron(sqrtW_ba_diag,ones(1,5)).*[J_ba_rot J_ba_trans];

J_ba_G1_norm = J_ba_motion_norm(:,1);
J_ba_G2_norm = J_ba_motion_norm(:,2);
J_ba_G3_norm = J_ba_motion_norm(:,3);
J_ba_G4_norm = J_ba_motion_norm(:,4);
J_ba_G5_norm = J_ba_motion_norm(:,5);

r_ba_norm = sqrtW_ba_diag.*r_ba(:);

J_prior_d_diag_norm = sqrt(a_t);
r_prior_norm = sqrt(a_t).*r_dispPrior;

a = sum(reshape(J_ba_disp_diag_norm.*r_ba_norm,2,nbPt),1)' + J_prior_d_diag_norm.*r_prior_norm;
b = J_ba_motion_norm'*r_ba_norm;

%compute H_mm
H_mm = J_ba_motion_norm'*J_ba_motion_norm + diag([zeros(1,3) 1e-7*ones(1,2)]);

%compute H_md
H_md_1 = sum(reshape(J_ba_G1_norm.*J_ba_disp_diag_norm,2,nbPt),1);
H_md_2 = sum(reshape(J_ba_G2_norm.*J_ba_disp_diag_norm,2,nbPt),1);
H_md_3 = sum(reshape(J_ba_G3_norm.*J_ba_disp_diag_norm,2,nbPt),1);
H_md_4 = sum(reshape(J_ba_G4_norm.*J_ba_disp_diag_norm,2,nbPt),1);
H_md_5 = sum(reshape(J_ba_G5_norm.*J_ba_disp_diag_norm,2,nbPt),1);

H_md = [H_md_1; H_md_2; H_md_3; H_md_4; H_md_5];
%compute inv_dd
invH_dd = 1./(sum(reshape(J_ba_disp_diag_norm.*J_ba_disp_diag_norm,2,nbPt),1)' + J_prior_d_diag_norm.*J_prior_d_diag_norm)';

%compute H_md*invH_dd
H_md_x_invH_dd_1 = H_md_1.*invH_dd;
H_md_x_invH_dd_2 = H_md_2.*invH_dd;
H_md_x_invH_dd_3 = H_md_3.*invH_dd;
H_md_x_invH_dd_4 = H_md_4.*invH_dd;
H_md_x_invH_dd_5 = H_md_5.*invH_dd;

H_md_x_invH_dd = [H_md_x_invH_dd_1; H_md_x_invH_dd_2; H_md_x_invH_dd_3; H_md_x_invH_dd_4; H_md_x_invH_dd_5];

%solve system camera
A = H_mm - H_md_x_invH_dd*(H_md');
delta_m = mldivide(A,b - H_md_x_invH_dd*a);

%solve depth
delta_disp = invH_dd'.*a - H_md_x_invH_dd'*delta_m;

delta_Rcr = delta_m(1:3);
delta_Rtcr= delta_m(4:5);
end

  %  [Rcr, Rtcr, disparity, condOut] = lineSearch(nbPt,delta_Rcr,delta_Rtcr,delta_disparity,Rcr,Rtcr,disparity,xr,xc,disparity_prior,a_t,resPrec);

function [Rcr, Rtcr, disparity, condOut, resMin] = lineSearch(nbPt,delta_Rcr,delta_Rtcr,delta_disparity,Rcr,Rtcr,disparity,xr,xc,disparity_prior,a_t,resPrec)

condOut = true;

nbSubsteps = 10;
alpha = 1./(2.^[0:nbSubsteps-1]);

resMin = resPrec;

for i = 1:nbSubsteps
    
    Rcr_New = expSO3(alpha(i)*delta_Rcr)*Rcr;
    Rtcr_New = Rtcr*expSO3(alpha(i)*[delta_Rtcr;0]);
    
    disparity_New = max(0,disparity + alpha(i)*delta_disparity);
    
    [r_ba_New, r_dispPrior_New] = computeError(xc, xr, Rcr_New, Rtcr_New, disparity_New, disparity_prior);
    
    resNew = computeResidual(r_ba_New, r_dispPrior_New, a_t);
    
    if((resNew + 1e-7) < resPrec)
        Rcr = Rcr_New;
        Rtcr = Rtcr_New;
        disparity = disparity_New;
        condOut = false;
                resMin = resNew;

        disp(num2str(resNew,'%10.5e'));
        break;
    end
    
end


end
function w_ba = computeWeights(r_ba)
% r_c = 1e2*r_c;
% w_c = 1./sqrt(1+sum(r_c.^2,1)/2);%L1-L2

r_ba = 5e2*r_ba;
w_ba = 1./((1+sum(r_ba.^2,1)).^2);%Geman-McClure

end

function res = computeResidual(r_ba, r_dispPrior, a_t)
% r_c = 1e2*r_c;
% res = sum(2*(sqrt(1+sum(r_c.^2,1)/2)-1));%L1-L2

r_ba = 5e2*r_ba;
res = sum(0.5*sum(r_ba.^2,1)./(1+sum(r_ba.^2,1))) + sum(a_t.*(r_dispPrior.^2));%Geman-McClure

end
