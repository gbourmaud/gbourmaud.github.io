function F = eightpoint(X1, X2)

% Normalize the points following the centroid normalization recommended
% by Zisserman (p109, p282)
[X1t,T1] = normalize2Dpoints(X1);
[X2t,T2] = normalize2Dpoints(X2);


% Arrange the matrix A.
A = zeros(size(X1t,2),9);
for i=1:size(X1t,2)
    A(i,:) = [X2t(1,i)*X1t(1,i),X2t(1,i)*X1t(2,i),X2t(1,i),X2t(2,i)*X1t(1,i),X2t(2,i)*X1t(2,i),X2t(2,i),X1t(1,i),X1t(2,i),1];
end;

%% Find the fundamental matrix F' in 2 steps
if(sum(sum(isnan(A)))==0)
    
    
    [Ua,Da, Va] = svd(A);
    
    % The matrix F' is composed of the elements of the last vector of V
    f = Va(:,end);
    
    % Reorganice h to obtain H
    Fp = reshape(f,3,3)';
    
    % Constraint enforcement: Replace F by F' such that det(F´)=0 using
    % SVD
    [Uf,Df,Vf] = svd(Fp);
    
    Df(end,end) = 0;
    Ff = Uf*Df*Vf';
else
    F = [0/0,0/0,0/0;0/0,0/0,0/0;0/0,0/0,0/0];
end

% Denormalization
F = T2'*Ff*T1;

