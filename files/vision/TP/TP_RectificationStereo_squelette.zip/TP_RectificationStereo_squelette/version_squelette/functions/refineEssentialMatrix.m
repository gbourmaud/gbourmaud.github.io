function [E, R21, T21]   = refineEssentialMatrix(K,F,X1inliers,X2inliers)

R21andT21 = getRelativeMotionFromFandK(K, K, F, X1inliers, X2inliers);
R21 = R21andT21(:,1:3);
T21 = R21andT21(:,4)/norm(R21andT21(:,4));

nbPt = size(X1inliers,2);

X1inliers_focal = inv(K)*X1inliers;
X2inliers_focal = inv(K)*X2inliers;

[d, T21] = linearTriangulation(X1inliers_focal, X2inliers_focal, R21, T21, nbPt);

Rt21 = sphere2MatRot(T21);
[R21, Rt21, d] = GNLineSearchBAPositiveDisparitySparse(R21, Rt21, d', X1inliers_focal, X2inliers_focal, nbPt);

T21 = Rt21*[0;0;1];
E = HatSO3(T21)*R21;
end