clear;
close all;
clc;
dbstop if error;
addpath(genpath('.'));

%% Chargement des images et de la matrice de calibration
im1=double(imread('./data/1.png'))/255;
im2=double(imread('./data/3.png'))/255;

K = [535.4 0 320.1;
    0 539.2 247.6;
    0 0 1];

%% Mise en correspondance automatique

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% détecter et décrire des points d'intérêt avec SIFT (utiliser vl_sift)
%TODO
% appariement (utiliser vl_ubcmatch)
%TODO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,
plotmatches(im1,im2,f1,f2,matches,'interactive',0);

i1 = matches(1,:)';
i2 = matches(2,:)';
numOfMatches = size(i1,1);
p1_hom = ones(3,numOfMatches);
p2_hom = ones(3,numOfMatches);
p1_hom(1:2,:) = f1(1:2,i1);
p2_hom(1:2,:) = f2(1:2,i2);

%% Estimation de la matrice fondamentale

NbItRansac = 500;
ThreshRansac = 1.5; %en pixels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%implémenter l'algorithme RANSAC avec un noyau binaire en utilisant l'algorithme des 8 correspondances (fonction eightpoint fournie)
% la fonction RANSAC renvoie la matrice fondamentale (matrice F), le nombre de correspondances jugées non-aberrantes (scalaire nbInliers) et un vecteur binaire de la taille du nombre de correspondances avec un "0" si une correspondance est considérée aberrante et "1" sinon (vecteur inliers).
%TODO [F, inliers, nbInliers] = ransacF(X1,X2,NbItRansac,ThreshRansac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,
plotmatches(im1,im2,f1,f2,matches(:,inliers),'interactive',0);

vgg_gui_F(im1, im2, F');

p1inliers_hom = p1_hom(:,inliers);
p2inliers_hom = p2_hom(:,inliers);

%% Raffinement de la matrice essentielle

[E, R21, T21] = refineEssentialMatrix(K,F,p1inliers_hom,p2inliers_hom);

F_new = inv(K')*E*inv(K);

vgg_gui_F(im1, im2, F_new');

%% Calcul des homographies permettant d'effectuer la rectification homographique

[Hn1, Hn2] = computeHomographyRectification(K, R21, T21);

%% Rectification homographique

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%implémenter une fonction qui applique l'homographie Hn1 à l'image im1 et l'homographie Hn2 à l'image im2.
%TODO [im1Rect,im2Rect] = rectifyImages(im1, im2, Hn1, Hn2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vgg_gui_F(im1Rect, im2Rect, vl_hat([1 0 0]));
