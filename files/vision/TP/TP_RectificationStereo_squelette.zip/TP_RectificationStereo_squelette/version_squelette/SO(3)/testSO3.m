function testSO3()

%     w = randn(3,1);
%     w = [1.1249; 1.3366;-0.45]
%     w = [0 0 0]
%     w = [1e-3 0 0]
   % w = [3.14 0 0]
    %w = [pi 0 0]
 %   w = [1.56 1.55 0]
    w = [0.02 0.1 0.04]

    w_hat = HatSO3(w)
    
    adjw = adjSO3(w)
    
    R = expSO3(w)
    
    AdR = AdSO3(R)
    
    Rinv = invSO3(R)
    
    logSO3(R)