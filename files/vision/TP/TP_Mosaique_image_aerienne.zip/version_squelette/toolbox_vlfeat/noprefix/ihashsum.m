function varargout = ihashsum(varargin)
[varargout{1:nargout}] = vl_ihashsum(varargin{:});
