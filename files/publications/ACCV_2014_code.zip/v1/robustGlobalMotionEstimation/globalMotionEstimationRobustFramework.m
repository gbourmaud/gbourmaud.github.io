function [Tig,inliers,minST,voteMatrix,i,bool] = globalMotionEstimationRobustFramework(Gweight,Tij,cov_ij_i,sizeMatrixLieGroup,nbDoF,invG,logG,AdG,expG,nbSTMax,thresh,plotOn)


if(~isequal(Gweight,Gweight'))
    error('G has to be symmetric while Tij is upper triangular');
end

nbItMax = 100;

for i = 1:nbSTMax
    i
    minST = findMinimumSpanningTree(Gweight);
    
    [Tig,inliers,voteMatrix] = IEKFAndVoteGlobalMotion(minST,Gweight,Tij,cov_ij_i,sizeMatrixLieGroup,nbDoF,invG, logG, AdG, expG,nbItMax,thresh,plotOn);
    
    voteMatrix = triu(voteMatrix) + tril(voteMatrix)';
    
    [Gweight,bool] = updateGweight(Gweight,minST,voteMatrix);
    
    figure(2),imagesc((voteMatrix+voteMatrix')>0),drawnow;
    
    
    if(bool)
        break;
    end
end

end

function [Gweight,bool] = updateGweight(Gweight,minST,voteMatrix)

nbRMinST = size(minST,1);

bool = true;

maxWeight = max(max(Gweight));
for i = 1:nbRMinST
    
    k = minST(i,1);
    l = minST(i,2);
    if(voteMatrix(min(k,l),max(k,l))==0)
        Gweight(k,l) = 0;%maxWeight;
        Gweight(l,k) = 0;%maxWeight;
        bool = false;
    end
end

end
