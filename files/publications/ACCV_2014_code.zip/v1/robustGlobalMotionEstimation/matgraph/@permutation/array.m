function a = array(p)
% array(p) --- return p as an array 
a = p.array;