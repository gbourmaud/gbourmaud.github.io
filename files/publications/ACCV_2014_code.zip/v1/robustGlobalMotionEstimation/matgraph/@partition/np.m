function m = np(p)
% np(p) --- number of parts in the partition p
m = size(p.array,1);