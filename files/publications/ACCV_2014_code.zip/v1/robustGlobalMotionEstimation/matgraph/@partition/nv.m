function n = nv(p)
% nv(p) --- number of vertices (elements) of a partition
n = size(p.array,2);
