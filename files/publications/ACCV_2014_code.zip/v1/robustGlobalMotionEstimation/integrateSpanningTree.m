function [Tig,inliers] = integrateSpanningTree(ST,Tij,sizeMatrixLieGroup,invG)

nbNode = size(Tij,1);

%spanning tree
Tig = cell(1,nbNode);
Tig{ST(1,1)} = eye(sizeMatrixLieGroup);

inliers = zeros(nbNode);

for iii = 1:size(ST,1)
    
    k = ST(iii,1);
    l = ST(iii,2);
    if(k<l)
        Tlk_temp = invG(Tij{k,l});

    elseif(k>l)
        Tlk_temp = Tij{l,k};

    end
    
    %% Propagation
    
    inliers(min(k,l),max(k,l)) = 1;

    Tig{l} = Tlk_temp*Tig{k};
   
    
end

end





