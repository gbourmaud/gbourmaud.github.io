function [imRect] = ImageRectification(im, H, bounds, xyscale)

if(~exist('xyscale','var'))
    xyscale = 1;
end
T = maketform('projective',H');

imRect = imtransform(im,T,'xdata', bounds(:,1)', 'ydata', bounds(:,2)','FillValues',NaN,'XYScale',xyscale);

maxIntensity = max(imRect(:));
if(maxIntensity>1)
    imRect = double(imRect)/double(maxIntensity);
end

return;
