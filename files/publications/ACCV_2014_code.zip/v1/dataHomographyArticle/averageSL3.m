function Hgnewg = averageSL3(Hig)
nbGM = size(Hig,2);

temp = zeros(3);
for i = 1:nbGM
    if(~isreal(Hig{i}))
        error('should be real');
    end
    temp = temp + Hig{i};
    %Hig{i}
end
temp = temp./nbGM;
Hgnewg = normalizeSL3(temp);
end