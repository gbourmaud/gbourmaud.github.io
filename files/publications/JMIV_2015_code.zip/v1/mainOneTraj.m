%% Initialisation
clear;
close all;
clc;
dbstop if error;

addpath(genpath('.'));

legenda = {...
    'go-';...
    'yo-';...
    'bo-';...
    'ko-';...
    'g^-';...
    'y^-';...
    'b^-';...
    'k^-';...
    'r'};

%% Trajectory Simulation
stepSize = 0.1;%time between 2 measurements in seconds
sequenceLength = 4;%seconds

paramTraj = paramTrajGen(stepSize,sequenceLength);
traj = generateTrajectoryDiscrete(paramTraj);


tailleCone = 0.1;
figure,plotTranslation(traj);
plotTrajCamCone(traj,tailleCone,tailleCone,tailleCone);

%% Noisy measurements simulation
paramObs = paramObsGen();
observations = generateObservations(traj,  paramObs);


%% Test filtres
filtersToTest = {...
    'CDLGEKFMajLG';...
    };

[filters, res] = initFilters(filtersToTest,paramTraj,paramObs,traj,observations);

res = testFilters(filters,res,observations,paramTraj);


%% Results
errorsToCompute = filtersToTest;
errorsToCompute{length(errorsToCompute)+1} = 'Obs';
res{length(res)+1} = observations;

printRes = 'disp';
[err_T err_R err_T_vect err_R_vect] = computeMSEFiltersOneTraj(res,traj,printRes,errorsToCompute);


plotMSEOneTraj(errorsToCompute,legenda,err_T_vect,err_R_vect,'log');

figure,
plotCurves(traj,observations,res(1:end-1),'simulated trajectory','measurements',{'CD-LG-EKF'},stepSize);






