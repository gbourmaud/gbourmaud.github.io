function Mobs = GstateToGobs(Mstate)

Mobs = eye(7);

Mobs(1:3,1:3) = Mstate(1:3,1:3);
Mobs(4:6,7) = Mstate(8:10,11);