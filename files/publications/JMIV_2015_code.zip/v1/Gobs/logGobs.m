function m = logGobs(M)

m = zeros(6,1);
m(1:3) = logSO3(M(1:3,1:3));
m(4:6) = M(4:6,7);

