function M = CellToMobs(C)

M = eye(7);
M(1:3,1:3) = C.R;
M(4:6,7) = C.T;