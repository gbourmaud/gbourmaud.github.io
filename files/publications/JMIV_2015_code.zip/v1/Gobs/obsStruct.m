function S = ObsStruct()

S.Ad = @AdGobs;
S.adj = @adjGobs;
S.CellToM = @CellToMobs;
S.exp = @expGobs;
S.fromState = @GstateToGobs;
S.Hat = @HatGobs;
S.inv = @invGobs; 
S.log = @logGobs;
S.MToCell = @MobsToCell;
S.Phi = @PhiGobs;
S.Vec = @VecGobs;