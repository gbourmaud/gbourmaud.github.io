function M = expGobs(m)

M = eye(7);

M(1:3,1:3) = expSO3(m(1:3));
M(4:6,7) = m(4:6);



