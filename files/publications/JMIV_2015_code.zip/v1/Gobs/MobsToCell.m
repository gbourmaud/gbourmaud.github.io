function C = MobsToCell(M)

C.R = M(1:3,1:3);
C.T = M(4:6,7);
