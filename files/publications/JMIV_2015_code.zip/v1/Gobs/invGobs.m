function Minv = invObs(M)

Minv = eye(7);
Minv(1:3,1:3) = invSO3(M(1:3,1:3)); 
Minv(4:6,7) = -M(4:6,7);