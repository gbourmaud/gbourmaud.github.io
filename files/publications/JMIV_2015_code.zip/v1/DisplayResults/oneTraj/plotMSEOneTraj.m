function [] = PlotMSEOneTraj(ErrorsToCompute,legenda,err_T_vect,err_R_vect,logOn)

nbRes = length(ErrorsToCompute);

figure('Name','MSE One Traj')
for i = 1:nbRes
    plotError([err_R_vect{i}'; err_T_vect{i}'],ErrorsToCompute{i},legenda{i},logOn); hold on;
end