function [err_T err_R err_T_vect err_R_vect] = computeMSEFiltersOneTraj(Res,TrajTrue,printRes,namefilters)

nbRes = length(Res);
err_T = zeros(1,nbRes);
err_R = zeros(1,nbRes);
err_T_vect = cell(1,nbRes);
err_R_vect = cell(1,nbRes);

for i = 1:nbRes
    [err_T(i) err_R(i)  err_T_vect{i}  err_R_vect{i} ] = computeErrTraj(Res{i},TrajTrue);
    
    if(strcmp(printRes,'disp'))
        disp([namefilters{i} ' :', ' err T : ',num2str(err_T(i)), ' err R : ', num2str(err_R(i))]);
    end
end