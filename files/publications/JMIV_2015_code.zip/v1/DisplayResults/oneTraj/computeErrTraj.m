function [err_T err_R err_T_vect err_R_vect] = ComputeErrTraj(TrajEst,TrajTrue)

npt = length(TrajEst);
w = zeros(3,npt);
t = zeros(3,npt);

err_T = 0;
err_R = 0;

err_T_vect = zeros(npt,1);
err_R_vect = zeros(npt,1);
for i=1:npt
    
    w(:,i) =  logSO3(invSO3(TrajEst{i}.C.R)*TrajTrue{i}.C.R).^2;
    t(:,i) =  (TrajEst{i}.C.T - TrajTrue{i}.C.T).^2;
    
    err_T = err_T + sum(t(:,i));
      
    err_R = err_R + sum(w(:,i));
    
    err_T_vect(i) = sum(t(:,i)); 
    err_R_vect(i) = sum(w(:,i));
end

err_T = err_T/npt;
err_R = err_R/npt;