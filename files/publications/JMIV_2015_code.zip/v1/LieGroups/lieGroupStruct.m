function S = LieGroupStruct(LiegroupName)

switch LiegroupName
    case 'SO3'
        S =  SO3Struct();
    case 'SE3'
        S =  SE3Struct();
    case 'SE2'
        S =  SE2Struct();
    case 'SL3'
        S =  SL3Struct();
end
end

%% SO(3)
function S = SO3Struct()

S.Ad = @AdSO3;
S.adj = @adjSO3;
S.CellToM = @CellToMatSO3;
S.exp = @expSO3;
S.Hat = @HatSO3;
S.inv = @invSO3;
S.log = @logSO3;
S.MToCell = @MatToCellSO3;
S.Phi = @PhiSO3;
S.Vec = @VecSO3;
end

function AdR = AdSO3(R)
AdR = R;
end
function adw = adjSO3(w)
adw = HatSO3(w);
end
function M = CellToMatSO3(C)
M = C.R;
end
function R = expSO3(w)
normw = norm(w);
if(normw == 0)
    R = eye(3);
    return;
end
w_hat = HatSO3(w);
R = eye(3) + sin(normw)*w_hat/normw + (1-cos(normw))*w_hat*w_hat/(normw^2);
end
function w_hat = HatSO3(w)
w_hat = [0 -w(3) w(2);...
    w(3) 0 -w(1);...
    -w(2) w(1) 0];
end
function Rinv = invSO3(R)
Rinv = R';
end
function w = logSO3(R)
phy = acos((trace(R)-1)/2);
if(abs(phy)> pi)
    warning('angle sup�rieur � pi');
    phy = phy - ceil(phy/pi)*pi;
end
if(phy == 0)
    w = zeros(3,1);
else
    w_hat = (R-R.')/(2*sin(phy))*phy;%on remultiplie par phy pour retrouver le vecteur avec sa norme originale
    w = VecSO3(w_hat);
end
end
function C = MatToCellSO3(R)
C.R = R;
end
function Phiw = PhiSO3(w)
normw = norm(w);
if(normw > 0)
    adw = adjSO3(w);
    
    Phiw = eye(3) + (1/(2*normw^2))*(4-normw*sin(normw)-4*cos(normw))*adw+...
        (1/(2*normw^3))*(4*normw-5*sin(normw)+normw*cos(normw))*adw^2+...
        (1/(2*normw^4))*(2-normw*sin(normw)-2*cos(normw))*adw^3+...
        (1/(2*normw^5))*(2*normw-3*sin(normw)+normw*cos(normw))*adw^4;
else
    Phiw = eye(3);
end
end
function w = VecSO3(w_hat)
w = [w_hat(3,2); w_hat(1,3); w_hat(2,1)];
end

%% SE(3)
function S = SE3Struct()

S.Ad = @AdSE3;
S.adj = @adjSE3;
S.CellToM = @CellToMatSE3;
S.exp = @expSE3;
S.Hat = @HatSE3;
S.inv = @invSE3;
S.log = @logSE3;
S.MToCell = @MatToCellSE3;
S.Phi = @PhiSE3;
S.Vec = @VecSE3;
end

function AdM = AdSE3(M)
R = M(1:3,1:3);
T = M(1:3,4);
AdM = zeros(6);
AdM(1:3,1:3) = R;
AdM(4:6,4:6) = R;
AdM(4:6,1:3) = HatSO3(T)*R;
end
function adm = adjSE3(m)
adw = HatSO3(m(1:3));

adT = HatSO3(m(4:6));

adm = [adw zeros(3,3); adT adw];
end
function M = CellToMatSE3(C)
M = eye(4); 
M(1:3,1:3) = C.R;
M(1:3,4) = C.T;
end
function M = expSE3(m)
% Fonctionne uniquement pour une rotation dans ]-pi, pi[

M = zeros(4);

w = m(1:3);
w_hat = HatSO3(w);
normw = norm(w);
v = m(4:6);
exptemp = expSO3(w);
M(1:3,1:3) = exptemp;

if(normw == 0)
    A = eye(3);
else
    A = eye(3) + (1 - cos(normw))*w_hat/(normw^2) + (normw - sin(normw))*w_hat*w_hat/normw^3;
end

M(1:3,4) = A*v;

M(4,4) = 1;
end
function m_hat = HatSE3(m)
m_hat = zeros(4);

m_hat(1:3,1:3) = HatSO3(m(1:3));
m_hat(1:3,4) = m(4:6);
end
function Minv = invSE3(M)
Minv = zeros(4);
Minv(4,4) = 1;
Minv(1:3,1:3) = M(1:3,1:3)';
Minv(1:3,4) = -M(1:3,1:3)'*M(1:3,4);
end
function m = logSE3(M)

% Fonctionne uniquement pour une rotation dans ]-pi, pi[

m = zeros(6,1);
T = M(1:3,4);
R = M(1:3,1:3);
w = logSO3(R);
w_hat = HatSO3(w);
normw = norm(w);

if(normw == 0)
    m(4:6) = T;
else
    m(1:3) = w;
    A_inv = eye(3) - 0.5*w_hat + (2*sin(normw) - normw*(1+cos(normw)))*w_hat*w_hat/(2*(normw^2)*sin(normw));
    m(4:6) = A_inv*T;
end

end
function C = MatToCellSE3(M)
C.R = M(1:3,1:3);
C.T = M(1:3,4);
end
function Phiw = PhiSE3(w)
error('non impl�ment�');
end
function m = VecSE3(m_hat)

m = zeros(6,1);

m(4:6) = m_hat(1:3,4);
m(1:3) = VecSO3(m_hat(1:3,1:3));
end


%% SE(2)

%% SL(3)
