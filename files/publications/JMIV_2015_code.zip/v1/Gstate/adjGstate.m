function adm = adjGstate(m)

adm = zeros(12);
adm(1:3,1:3) = adjSO3(m(1:3));