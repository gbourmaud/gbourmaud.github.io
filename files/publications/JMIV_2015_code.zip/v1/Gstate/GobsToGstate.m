function Mstate = GobsToGstate(Mobs)

Mstate = eye(15);

Mstate(1:3,1:3) = Mobs(1:3,1:3);
Mstate(8:10,11) = Mobs(4:6,7);
