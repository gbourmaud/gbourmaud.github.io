function m = logGstate(M)

m = zeros(12,1);

m(1:3) = logSO3(M(1:3,1:3));
m(4:6) = M(4:6,7);
m(7:9) = M(8:10,11);
m(10:12) = M(12:14,15);

