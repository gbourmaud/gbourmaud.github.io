function M = expGstate(m)

M = eye(15);

M(1:3,1:3) = expSO3(m(1:3));
M(4:6,7) = m(4:6);
M(8:10,11) = m(7:9);
M(12:14,15) = m(10:12);


