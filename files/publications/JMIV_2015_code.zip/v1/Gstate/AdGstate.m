function AdM = AdGstate(M)

AdM = eye(12);
AdM(1:3,1:3) = M(1:3,1:3);