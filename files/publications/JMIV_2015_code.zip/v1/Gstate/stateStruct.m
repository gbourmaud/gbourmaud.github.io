function S = stateStruct()

S.Ad = @AdGstate;
S.adj = @adjGstate;
S.CellToM = @cellToMstate;
S.exp = @expGstate;
S.fromObs = @GobsToGstate;
S.getL = @getLstate;
S.Hat = @hatGstate;
S.log = @logGstate;
S.MToCell = @MstateToCell;
S.Phi = @phiGstate;
S.Vec = @vecState;