function L = getLstate()

L = cell(12);

nbDoF = 12;
for i = 1:nbDoF
    for j = 1:nbDoF
        
        L{i,j} = zeros(nbDoF,1);
    end
end

L{1,2}(3) = -1;
L{1,3}(2) = 1;
L{2,1}(3) = 1;
L{2,3}(1) = -1;
L{3,1}(2) = -1;
L{3,2}(1) = 1;

% %test
% a = randn(3,1);
% ad = adjSO3(a);
% for i = 1:3
%     for j = 1:3
%         adbis(i,j) = L{i,j}(1:3)'*a;
%     end
% end
% ;