function C = MstateToCell(M)

C.R = M(1:3,1:3);
C.w = M(4:6,7);
C.T = M(8:10,11);
C.v = M(12:14,15);