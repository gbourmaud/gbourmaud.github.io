function hatM = hatGstate(m)

hatM = zeros(15);

hatM(1:3,1:3) = HatSO3(m(1:3));
hatM(4:6,7) = m(4:6);
hatM(8:10,11) = m(7:9);
hatM(12:14,15) = m(10:12);
