function M = cellToMstate(C)

M = eye(15);
M(1:3,1:3) = C.R;
M(4:6,7) = C.w;
M(8:10,11) = C.T;
M(12:14,15) = C.v;