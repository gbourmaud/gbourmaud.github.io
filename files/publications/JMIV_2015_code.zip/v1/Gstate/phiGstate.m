function Phim = phiGstate(m)

Phim = eye(12);
Phim(1:3,1:3) = PhiSO3(-m(1:3));%-m car le phi de SO3 n'a pas le (-1)^n dans sa d�finition