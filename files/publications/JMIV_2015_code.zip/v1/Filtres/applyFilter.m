function [Smaj, Sprop] = applyFilter(Sprec, observations, funs)

%propagation
Sprop = funs.prop.fun(Sprec,funs);

%mise � jour
Smaj = funs.maj.fun(Sprop,observations,funs);