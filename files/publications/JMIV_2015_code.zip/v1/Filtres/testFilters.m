function res = testFilters(filters,res,observations,paramTraj)

nbfilters = length(filters);

for i = 1:nbfilters
    res{i} = testFilter(filters{i}, res{i}, observations,paramTraj);
end