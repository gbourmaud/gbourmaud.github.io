function [filters, res] = initFilters(filtersToTest,paramTraj,paramObs,traj,observations)

nbfilters = length(filtersToTest);
filters = cell(1,nbfilters);
res = cell(1,nbfilters);

for i = 1:nbfilters
    [filters{i}, res{i}] = initFilter(filtersToTest{i},paramTraj,paramObs,traj,observations);
end