function Sprop = CDLGEKFPropFun(Sprec,funs)

stepSize = funs.prop.params.DeltaT;
nbStep = funs.prop.params.nbStep;
deltat = stepSize/nbStep;

mu = Sprec.M;
muCell = funs.state.MToCell(mu);
P = Sprec.P;
R = funs.prop.params.R;

%L = funs.state.getL();
for i = 1:nbStep
    %i
    omega = zeros(12,1);
    omega(1:3) = muCell.w;
    omega(7:9) = muCell.v;
    
    
    %prop covariance
    
    F = zeros(12);
    F(1:3,4:6) = eye(3);
    F(7:9,10:12) = eye(3);
    
    %     C = computeC(R,L);
    %     adRad = computeadRad(R,L,P);
    %     adad = computeadad(L,P);
    %
    %     J = F - funs.state.adj(omega) + (1/12)*C;
    %
    %     f = J*P + P*(J') + R + (1/4)*adRad + (1/12)*adad*R + (1/12)*R*(adad');
    %additionnal terms are null with the specified R
    
    J = F - funs.state.adj(omega);
    
    f = J*P + P*(J') + R;
    
    lP = svd(P);
    if(~isreal(lP))
        error('not real');
    end
    lfdeltat = svd(f*deltat);
    
    alphaMax = min(lP)/max(lfdeltat);
    alphaMax = 0.1*alphaMax; % pour s'assurer d'être stritement inférieur
    
    alpha = min([1e-3 alphaMax]);
    %alpha =
    P = expm((1/alpha)*(logm(P+alpha*f*deltat)-(1-alpha)*logm(P)));
    %prop moyenne
    
    mu = mu*funs.state.exp(omega*deltat);
    muCell = funs.state.MToCell(mu);
    
    
    
end

Sprop.M = mu;
Sprop.C = muCell;
Sprop.P = P;

end


function C = computeC(R,L)


nbDoF = 12;

dbdbT = zeros(nbDoF);

for j = 1:nbDoF
    for k = 1:nbDoF
        ej = zeros(nbDoF,1);
        ej(j) = 1;
        ek = zeros(nbDoF,1);
        ek(k) = 1;
        dbdbT = dbdbT +ej*(ek')*R(j,k);
    end
end

C = zeros(nbDoF);

for i = 1:nbDoF
    for j = 1:nbDoF
        for k = 1:nbDoF
            C(i,j) = C(i,j) + (L{i,k}')*dbdbT*L{k,j};
        end
    end
end


end

function adRad = computeadRad(R,L,P)

nbDoF = 12;
adRad = zeros(nbDoF);
for i = 1:nbDoF
    for j = 1:nbDoF
        for k = 1:nbDoF
            for l = 1:nbDoF
                
                adRad(i,j) = adRad(i,j) + R(k,l)*(L{i,k}')*P*L{j,l};
            end
        end
        
    end
end
end

function adad = computeadad(L,P)

nbDoF = 12;
adad = zeros(nbDoF);
for i = 1:nbDoF
    for j = 1:nbDoF
        for k = 1:nbDoF
            
            
            adad(i,j) = adad(i,j) + (L{i,k}')*P*L{k,j};
            
        end
        
    end
end
end