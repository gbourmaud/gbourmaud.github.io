function Smaj = CDLGEKFMajFunLG(Sprop,Observations,funs)

H = zeros(6,12);
H(1:3,1:3) = eye(3);
H(4:6,7:9) = eye(3);


K = Sprop.P*H'*inv(H*Sprop.P*H'+Observations.Cov);

Obspred = funs.obs.fromState(Sprop.M);
m = K*funs.obs.log(funs.obs.inv(Obspred)*Observations.M);

Smaj.M = Sprop.M * funs.state.exp(m);
Smaj.C = funs.state.MToCell(Smaj.M);

phi = funs.state.Phi(m);
Smaj.P = phi*(eye(12)-K*H)*Sprop.P*phi';