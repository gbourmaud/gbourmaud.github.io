function [filter, resStruct] = initFilter(namefilter,paramTraj,paramObs,traj,observations)

covprecisR = 1e-2;
covprecisT = 1e-2;
covnonprecisw = 1e4;
covnonprecisv = 1e4;
covInit = blkdiag(covprecisR*eye(3), covnonprecisw*eye(3), covprecisT*eye(3), covnonprecisv*eye(3));

objStateStruct = stateStruct;
Minit = objStateStruct.fromObs(observations{1}.M);

if(strcmp(namefilter,'CDLGEKFMajLG'))
    filter.state = stateStruct;
    filter.obs = obsStruct;
    filter.prop.fun = @CDLGEKFPropFun;
    filter.prop.params.nbStep = paramTraj.nbStep;
    filter.prop.params.DeltaT = paramTraj.stepSize;
    filter.prop.params.R = paramTraj.R;
    filter.maj.fun = @CDLGEKFMajFunLG;
    resStruct = cell(1,paramTraj.nbViews);
    resStruct{1}.M = Minit;%initialisationde l'�tat
    resStruct{1}.P = covInit;
    resStruct{1}.C = filter.state.MToCell(resStruct{1}.M);
    
end