
function resStruct = testFilter(filter, resStruct, observations, paramTraj)

for i = 2:paramTraj.nbViews
    i
    [resStruct{i}] = applyFilter(resStruct{i-1}, observations{i}, filter);
end

end