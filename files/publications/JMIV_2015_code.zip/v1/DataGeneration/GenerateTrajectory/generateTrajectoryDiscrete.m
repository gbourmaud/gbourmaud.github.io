function Traj = generateTrajectoryDiscrete(paramTraj)

Traj = cell(1,paramTraj.nbViews);

Traj{1}.C.T = paramTraj.Tgb_init;
Traj{1}.C.R = paramTraj.Rgb_init;
Traj{1}.C.v = paramTraj.vb_init;
Traj{1}.C.w = paramTraj.wb_init;
Traj{1}.M = cellToMstate(Traj{1}.C);
angSpeed = paramTraj.wb_init;
transSpeed = paramTraj.vb_init;
Rgb = paramTraj.Rgb_init;
Tgb = paramTraj.Tgb_init;


sqrtR = sqrtm(paramTraj.R);
stepSize = paramTraj.stepSize;
nbStep = paramTraj.nbStepGen;
deltat = stepSize/nbStep;

for i = 2 : paramTraj.nbViews
    
    [Rgb, angSpeed, Tgb, transSpeed] = propagate(Rgb, angSpeed, Tgb, transSpeed, sqrtR, nbStep, deltat);
    
    Traj{i}.C.R = Rgb;
    Traj{i}.C.w = angSpeed;
    Traj{i}.C.T = Tgb;%OgOb in ref g
    Traj{i}.C.v = transSpeed;
    Traj{i}.M = cellToMstate(Traj{i}.C);
    Traj{i}.Cov = paramTraj.R;
    
end

end

function [Rgb, angSpeed, Tgb, transSpeed] = propagate(Rgb, angSpeed, Tgb, transSpeed, sqrtR, nbStep, deltat)

for i = 1:nbStep
    
    deltanoise = sqrtR*randn(12,1)*sqrt(deltat);
    
    Tgb = Tgb + transSpeed*deltat + deltanoise(7:9);
    transSpeed = transSpeed + deltanoise(10:12);
    
    Rgb = Rgb*expSO3(angSpeed*deltat+deltanoise(1:3));
    angSpeed = angSpeed + deltanoise(4:6);
end
end