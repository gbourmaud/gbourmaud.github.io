function [paramTraj] = paramTrajGen(stepSize,sequenceLength)

paramTraj.nbStepGen = 100;%nbSteps between 2 measurements
paramTraj.nbViews = round(sequenceLength/stepSize);
paramTraj.stepSize = stepSize; 

paramTraj.nbStep = 10;%nbSteps between 2 measurements during filtering

paramTraj.Rgb_init = expSO3([0;0;-3*pi/4])*expSO3([-pi/2;0;0])*expSO3([0;-pi/2;0]);
paramTraj.wb_init = zeros(3,1);
paramTraj.Tgb_init = [0; 0; 0];
paramTraj.vb_init = zeros(3,1);


Rw = [10^-3 0 0; 0 (pi/4)^2 0; 0 0 10^-3];

Rv = [1 0 0; 0 1 0; 0 0 10^-3];

paramTraj.R = [zeros(3) zeros(3) zeros(3) zeros(3);...
    zeros(3) Rw zeros(3) zeros(3);...
    zeros(3) zeros(3) zeros(3) zeros(3);...
    zeros(3) zeros(3) zeros(3) Rv];

disp(['v : ', num2str(norm(paramTraj.vb_init)) ' m/s', ' w : ' num2str(norm(paramTraj.wb_init)) ' rad/s', ' dt : ' num2str(paramTraj.stepSize) ' s']);