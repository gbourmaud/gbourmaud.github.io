function J = computeJacobian(coordPoints3D,R_hat,T_hat)

nbApp = size(coordPoints3D,2);

J = zeros(2*nbApp,6);

for i = 1 : nbApp
    
    X = coordPoints3D(:,i);
    X_proj = ((R_hat')*(X - T_hat));
    u = X_proj(1);
    v = X_proj(2);
    w = X_proj(3);
    w_2 = w^2;
    
    P = [1/w 0   -u/w_2;...
         0   1/w -v/w_2;];
     
    X_cross = HatSO3(R_hat'*(X-T_hat));
        
    Ji = P*[X_cross -(R_hat')];
    
    J(1+2*(i-1):2*i,:)=Ji;
end