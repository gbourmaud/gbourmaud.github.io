function [X_rectifie_pruned,indices_pt_3D] = elagage(X_rectifie, image_size, K_inv)

%Supprime les points 3D qui ne seront pas reprojet�s dans l'image

X_pix = [0 0             image_size(1) image_size(1);...
    0 image_size(2) image_size(2) 0            ;...
    1 1             1             1            ];

X = K_inv*X_pix;
X = X./repmat(X(3,:),3,1);

max_x = max(X(1,:));
min_x = min(X(1,:));
max_y = max(X(2,:));
min_y = min(X(2,:));

mask_w_1 = X_rectifie(1,:) >= min_x;
mask_w_2 = X_rectifie(1,:) <= max_x;
mask_h_1 = X_rectifie(2,:) >= min_y;
mask_h_2 = X_rectifie(2,:) <= max_y;

mask_final = mask_w_1 .* mask_w_1 .* mask_w_2 .* mask_h_1 .* mask_h_2;

indices_pt_3D = find(mask_final);

X_rectifie_pruned = X_rectifie(logical(repmat(mask_final,3,1)));

if(~isempty(X_rectifie_pruned))
    X_rectifie_pruned = reshape(X_rectifie_pruned,3,length(X_rectifie_pruned)/3);
end