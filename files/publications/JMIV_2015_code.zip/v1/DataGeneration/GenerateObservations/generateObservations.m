function observations = GenerateObservations(traj, paramObs)

Q = paramObs.Q;
Qpt3D = paramObs.Qpt3D;
image_size = paramObs.image_size;
K_inv = paramObs.K_inv;
nbAppMax = paramObs.nbAppMax;


posCam = cell2mat(cellfun(@(x) x.C.T,traj,'UniformOutput',false));
xmin = min(posCam(1,:));
xmax = max(posCam(1,:));
ymin = min(posCam(2,:));
ymax = max(posCam(2,:));
zmin = min(posCam(3,:));
zmax = max(posCam(3,:));

pointCloud3D = generateWallFeatures();

pointCloud3D = [pointCloud3D(1,:)*(xmax-xmin)*4;pointCloud3D(2,:)*(ymax-ymin)*4;pointCloud3D(3,:)*3];

pointCloud3DEst = pointCloud3D + sqrtm(Qpt3D)*randn(3,size(pointCloud3D,2));%3D noisy point cloud

nbViews = length(traj);
observations = cell(1,nbViews);

cholQ = sqrtm(paramObs.Q);

for i = 1:nbViews
    
    %generate features projected in the image plane with white noise
    
    [observations{i}.features, observations{i}.idsPt3D] = reprojection(traj{i}.C.R', -traj{i}.C.R'*traj{i}.C.T, pointCloud3D, image_size, K_inv);

    
    nbPt = length(observations{i}.idsPt3D);
    if(nbPt<4)
        
        error('not enough points');
        
    else
        ids = randperm(length(observations{i}.idsPt3D));
        selectedIds = ids(1:min(nbAppMax,nbPt));
        observations{i}.features = observations{i}.features(:,selectedIds) + cholQ*randn(2,length(selectedIds));
        observations{i}.Q = Q;
        
        
        %generate a meaningfull covariance measurement matrix
        [~,~, observations{i}.Cov, ~]  = gaussNewtonMinimizationReprojectionError(pointCloud3DEst(:,observations{i}.idsPt3D(selectedIds)), observations{i}.features, traj{i}.C.R,traj{i}.C.T,Q,Qpt3D);
       
        sqrtP = sqrtm(observations{i}.Cov);
        noiseSamp = sqrtP*randn(6,1);
        observations{i}.C.R = traj{i}.C.R*expSO3(noiseSamp(1:3));
        observations{i}.C.T = traj{i}.C.T + noiseSamp(4:6);
    end

    observations{i}.M = cellToMobs(observations{i}.C);
end

end

function features = generateWallFeatures()

nbFace = 6;
h = 1;

M = cell(nbFace,1);%M_gi permet d'exprimer un point 3D exprim� dans le r�f�rentiel de la face i dans le r�f�rentiel global


% ---->g        ---->i   ------>g
% O_g A  = R_gi O_i A  + O_g O_i = expSO3(w(:,i))*p+t(:,i)


t = [0 h h 0 0 0;...
    0 0 h h 0 0; ...
    0 0 0 0 0 h];
t = t - h/2;  % le r�f�rentiel global est fix� au milieu de la pi�ce (coord h/2 h/2 h/2)
% figure, plot3(t(1,:),t(2,:),t(3,:),'x');
% grid on;
% axis square;
% axis equal;

% w = [0  0  0 0 -1 -1;...
%      0  0  0 0  0  0; ...
%      0 -1 -2 1  0  0];
%

w1 = [1   1  1 1 0 0;...
    0   0  0 0 0 0; ...
    0   0  0 0 0 0]*(pi/2);%axes de rotation de g vers i
w2 = [0  0 0 0 0 0;...
    0  0 0 0 0 0; ...
    0  1 2 -1 0 0]*(pi/2);%axes de rotation de i vers j


for i = 1:nbFace
    Mtemp = eye(4);
    Mtemp(1:3,1:3) = expSO3(w2(:,i))*expSO3(w1(:,i));%R_gi
    %----->g
    Mtemp(1:3,4) = t(:,i);     %O_g O_i
    M{i} = Mtemp;
end


%% G�n�re Features
nbFeat = nbFace*10000;
EpaisseurNuage = (1/20)*h;
numFaces = randi(nbFace,nbFeat,1);
numFaces = sort(numFaces,'ascend');

Featc = rand(nbFeat,2)*h; % tire x et y de nbFeat features dans une face
Featz = EpaisseurNuage*randn(nbFeat,1);% tire la profondeur de chaque point par rapport au mur

F = [numFaces'; Featc'; Featz'; ones(1,nbFeat)];% 1: num�ro de la face, 2:4 coord x, y et z dans le ref de la face (coin bas gauche)

features = zeros(4,nbFeat);%x, y et z dans le ref global en coordonn�es homog�nes, couleur

for i = 1:nbFeat
    features(1:4,i) = M{F(1,i)}*F(2:5,i); % le point 3D a �t� plac� dans le r�f�rentiel global
    features(5,i) = F(1,i);%couleur du point
end



%save('./cube.mat','Features');

end