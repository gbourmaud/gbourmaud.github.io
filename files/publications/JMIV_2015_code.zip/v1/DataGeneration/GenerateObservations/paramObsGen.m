function paramObs = paramObsGen()

covpt = 9;
Q = [covpt 0; 0 covpt];%3 pix std
f = 600;
h = 960;
w = 1280;
K =  [f 0;...
    0 f];
% paramObs.cam.k = [0 0];
paramObs.image_size =  [w h];
paramObs.K_inv = inv([f 0 w/2;...
    0 f h/2;...
    0 0 1]);
K_inv = inv(K);
paramObs.Q = K_inv*Q*(K_inv');


stdPt3d  =  0.1;%10 cm std over 3D points
paramObs.Qpt3D = (stdPt3d^2)*eye(3);


 paramObs.nbAppMax = 10;