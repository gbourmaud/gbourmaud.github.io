function [projected_points, indices_pt_3D] = reprojection(R, T, points_3D, image_size, K_inv)


ids = 1:size(points_3D,2);

%Projection focal plane
mat_rigid_body_motion = [R T; 0 0 0 1];
standard_mat_proj = [1 0 0 0; 0 1 0 0; 0 0 1 0];
X_rectifie = standard_mat_proj * mat_rigid_body_motion * [points_3D(:,ids); ones(1,size(ids,2))];
ids_front = find(X_rectifie(3,:)>0);
X_rectifie_front = X_rectifie(:,ids_front);%delete points behind camera
X_rectifie_front = X_rectifie_front./repmat(X_rectifie_front(3,:),3,1);

%delete points outside field of view
[X_rectifie_pruned,indices_pt_3D] = elagage(X_rectifie_front, image_size, K_inv);
indices_pt_3D = ids_front(indices_pt_3D);

projected_points = X_rectifie_pruned(1:2,:);
