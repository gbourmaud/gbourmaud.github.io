function [errVect, nptIn] = computeReprojectionError(R,T,coordPoints3D, coordPoints2D)

%Projection focal plane
mat_rigid_body_motion = [R T; 0 0 0 1];
standard_mat_proj = [1 0 0 0; 0 1 0 0; 0 0 1 0];
X_rectifie = standard_mat_proj * mat_rigid_body_motion * [coordPoints3D; ones(1,size(coordPoints3D,2))];
ids_front = find(X_rectifie(3,:)>0);
nptIn = length(ids_front);
X_rectifie = X_rectifie./repmat(X_rectifie(3,:),3,1);

projected_points = X_rectifie(1:2,:);


err_vect = coordPoints2D - projected_points;
errVect = err_vect(:);