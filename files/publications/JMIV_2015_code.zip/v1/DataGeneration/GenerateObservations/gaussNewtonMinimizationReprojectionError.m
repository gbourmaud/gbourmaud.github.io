function [R,T,matCovParam,err_min, err_init, err_end, nptIn] = gaussNewtonMinimizationReprojectionError(points3D, points2D, R_init, T_init, Q,Qpt3D)


R = R_init;%Rgb
T = T_init;%Tgb = OgOb in ref g

nbApp = size(points2D,2);

[errVect, nptIn] = computeReprojectionError(R',-R'*T,points3D, points2D);
err_min_prec = (errVect'*errVect)/nbApp;
err_init = err_min_prec;
nb_it = 0;
while (1)
    %R=Rgb
    %T=Tbg=ObOg in ref b
    
    if(nb_it>50)
        matCovParam = inv((J'*matPrecisAppFull*J));
        
        break;
    end
    nb_it = nb_it +1;
    
    J = computeJacobian(points3D,R,T);
    
    matPrecisAppFull = computeInformationMatrix(Q,Qpt3D,points3D,R,T);
    theta_inc = inv(J'*matPrecisAppFull*J)*(J'*matPrecisAppFull*errVect);
    
    Rw = expSO3(theta_inc(1:3));
    
    R_old = R;
    T_old = T;
    J_old = J;
    matPrecisAppFull_old = matPrecisAppFull;
    
    R = R*Rw;
    T = theta_inc(4:6) + T;
    
    errvect_prec = errVect;
    errVect = computeReprojectionError(R',-R'*T,points3D, points2D);
    err_min = (errVect'*errVect)/nbApp;
    if(err_min > err_min_prec)
        
        theta_inc = 0.1*theta_inc;
        R = R_old;
        T = T_old;
        R = R*Rw;
        T = theta_inc(4:6) + T;
        
        errvect_prec = errVect;
        errVect = computeReprojectionError(R',-R'*T,points3D, points2D);
        err_min = (errVect'*errVect)/nbApp;
        
        if(err_min > err_min_prec)
            R = R_old;
            T = T_old;
            errVect = errvect_prec;
            err_end = err_min_prec;
            matCovParam = inv((J_old'*matPrecisAppFull_old*J_old));
            break;
        end
    end
    err_min_prec = err_min;
    
    
end

%nb_it
errVect = reshape(errVect,2,nbApp);
err_min = sum(sqrt(sum(errVect.^2,1)))/nbApp;

end

function I = computeInformationMatrix(Q,Qpt3D,coordPoints3D,R_hat,T_hat)

J = computeJacobianNoisePt3D(coordPoints3D,R_hat,T_hat);

nbApp = size(coordPoints3D,2);

I = inv(Q+J(1:2,:)*Qpt3D*J(1:2,:)');
for i = 1:nbApp-1
    I = blkdiag( I, inv(Q+J(1+i*2:(i+1)*2,:)*Qpt3D*J(1+i*2:(i+1)*2,:)'));
end
%MatPrecisAppFull = eye(NbApp*2);

end

function J = computeJacobianNoisePt3D(coordPoints3D,R_hat,T_hat)

nbApp = size(coordPoints3D,2);

J = zeros(2*nbApp,3);

for i = 1 : nbApp
    
    X = coordPoints3D(:,i);
    X_proj = ((R_hat')*(X - T_hat));
    u = X_proj(1);
    v = X_proj(2);
    w = X_proj(3);
    w_2 = w^2;
    
    P = [1/w 0   -u/w_2;...
        0   1/w -v/w_2;...
        0 0 0];
    P = P(1:2,:);
    
    Ji = P*(R_hat');
    
    J(1+2*(i-1):2*i,:)=Ji;
end
end
