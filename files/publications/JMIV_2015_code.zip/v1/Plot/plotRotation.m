function plotRotation(Traj,initInd,endInd,legends,color)

nbPos = length(Traj);
X = zeros(3,nbPos);

for i = 1:nbPos
    X(:,i) = logSO3(Traj{i}.C.R);
    
end

subplot(311);
hold on;
plot(initInd:endInd,X(1,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
subplot(312);
hold on;
plot(initInd:endInd,X(2,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
subplot(313);
hold on;
plot(initInd:endInd,X(3,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end




