function [] = plotCurves(traj,observations,res,trajLeg,obsLeg,resLeg,stepsize)

[Xtraj,Wtraj] = transform(traj);
[Xobs,Wobs] = transform(observations);

nbRes = length(res);
for i = 1:nbRes
    [Xres{i},Wres{i}] = transform(res{i});
end

style = {'bo','k>','c<','or','g.'};

[~,nbEch] = size(Xtraj);
ech = (1:nbEch).*stepsize;

subplot(321);
hold on;
grid on;
%axis equal;
plot(ech,Xtraj(1,:),'r*');
plot(ech,Xobs(1,:),'gs');
for i = 1:nbRes
    plot(ech,Xres{i}(1,:),style{i});
end

xlabel('t');
ylabel('x');
subplot(323);
hold on;
grid on;
%axis equal;
plot(ech,Xtraj(2,:),'r*');
plot(ech,Xobs(2,:),'gs');
for i = 1:nbRes
    plot(ech,Xres{i}(2,:),style{i});
end
xlabel('t');
ylabel('y');
subplot(325);
hold on;
grid on;
%axis equal;
plot(ech,Xtraj(3,:),'r*');
plot(ech,Xobs(3,:),'gs');
for i = 1:nbRes
    plot(ech,Xres{i}(3,:),style{i});
end
xlabel('t');
ylabel('z');
subplot(322);
hold on;
grid on;
%axis equal;
plot(ech,Wtraj(1,:),'r*');
plot(ech,Wobs(1,:),'gs');
for i = 1:nbRes
    plot(ech,Wres{i}(1,:),style{i});
end
xlabel('t');
ylabel('wx');
subplot(324);
hold on;
grid on;
%axis equal;
plot(ech,Wtraj(2,:),'r*');
plot(ech,Wobs(2,:),'gs');
for i = 1:nbRes
    plot(ech,Wres{i}(2,:),style{i});
end
xlabel('t');
ylabel('wy');
subplot(326);
hold on;
grid on;
%axis equal;
plot(ech,Wtraj(3,:),'r*');
plot(ech,Wobs(3,:),'gs');
for i = 1:nbRes
    plot(ech,Wres{i}(3,:),style{i});
end
xlabel('t');
ylabel('wz');

legend(trajLeg,obsLeg,resLeg{:});
end

function [X,W] = transform(traj)

nbPos = length(traj);
X = zeros(3,nbPos);

for i = 1:nbPos
    X(:,i) = traj{i}.C.T;
    
    W(:,i) = logSO3(traj{i}.C.R);
    
end

end