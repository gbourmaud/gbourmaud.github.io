function plotError(Err,legends,color,logOn)

if(strcmp(logOn,'log'))
    Err = log(Err);
end
nbPos = length(Err);

subplot(211);
hold on;
plot(1:nbPos,Err(1,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Rotation');
subplot(212);
hold on;
plot(1:nbPos,Err(2,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Translation');
