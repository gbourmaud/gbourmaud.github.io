function h = PlotTrajCamCone(traj,varargin)

if(nargin > 1 && ~isempty(varargin{1}))
    largeur_cone = varargin{1};
else
    largeur_cone = 1;
end

if(nargin > 2 && ~isempty(varargin{2}))
    hauteur_cone = varargin{2};
else
    hauteur_cone = largeur_cone;
end

if(nargin > 3 && ~isempty(varargin{3}))
    profondeur_cone = varargin{3};
else
    profondeur_cone = 1;
end

if(nargin > 4 && ~isempty(varargin{4}))
    color = varargin{4};
else
    color = 'g';
end

if(nargin > 6 && ~isempty(varargin{5}) && ~isempty(varargin{6}))
    refresh_fig = varargin{5};
    h = varargin{6};
else
    refresh_fig = 'no_refresh';
end

if(strcmp(refresh_fig,'no_refresh'))
    h = zeros(length(traj),4);
end

base = zeros(3,4);
for i=1:length(traj)
    Tgb = traj{i}.C.T;% OgOb dans g
    Rgb = traj{i}.C.R;
    
  
    
    center = Tgb;
    base(:,1) = Rgb * [ largeur_cone/2;  hauteur_cone/2; profondeur_cone] + Tgb;
    base(:,2) = Rgb * [ largeur_cone/2; -hauteur_cone/2; profondeur_cone] + Tgb;
    base(:,3) = Rgb * [-largeur_cone/2; -hauteur_cone/2; profondeur_cone] + Tgb;
    base(:,4) = Rgb * [-largeur_cone/2;  hauteur_cone/2; profondeur_cone] + Tgb;
    %%optical_axis = Rgb*[0; 0; -1] + Tgb;
    
    if(strcmp(refresh_fig,'no_refresh'))
        h(i,:) = plotCone(center, base, color);
    else
        plotCone(center, base, color, 'refresh', h(i,:));
    end
    hold on;
end
