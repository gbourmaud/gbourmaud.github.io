function plotTranslation(Traj,color)

if(~exist('color','var'))
    color = 'b';
end
nbPos = length(Traj);
X = zeros(3,nbPos);

for i = 1:nbPos
    X(:,i) = Traj{i}.C.T;%OgOb dans g
    
end

hold on;
plot3([0 1],[0 0],[0 0],'r');
plot3([0 0],[0 1],[0 0],'g');
plot3([0 0],[0 0],[0 1],'b');

plot3(X(1,:),X(2,:),X(3,:),color);

grid on;
axis equal;
cameratoolbar;
xlabel('x');
ylabel('y');
zlabel('z');
% oldleg = get(legend);
% if(~isempty(oldleg))
%     legend(oldleg.String,legends);
% else
%     legend(legends);
% end
% subplot(312);
% hold on;
% plot(initInd:endInd,X(2,:),color);
% oldleg = get(legend);
% if(~isempty(oldleg))
%     legend(oldleg.String,legends);
% else
%     legend(legends);
% end
% subplot(313);
% hold on;
% plot(initInd:endInd,X(3,:),color);
% oldleg = get(legend);
% if(~isempty(oldleg))
%     legend(oldleg.String,legends);
% else
%     legend(legends);
% end
% 
% 


