function h = PlotCone(pic, base, varargin)

if(nargin > 2)
    color = varargin{1};
else
    color = 'g';
end

if(nargin > 4 && ~isempty(varargin{2}) && ~isempty(varargin{3}))
    refresh_fig = varargin{2};
    h = varargin{3};

else
    refresh_fig = 'no_refresh';
end
%la face droite de la pyramide est en rouge afin de reconna�tre
%l'orientation

% on trace 4 polygones, chaque polygone est un triangle, le tout forme
% une pyramide

x = [pic(1)    pic(1)    pic(1); ...
    base(1,1) base(1,2) base(1,3);...
    base(1,4) base(1,3) base(1,4)];

y = [pic(2)    pic(2)    pic(2);...
    base(2,1) base(2,2) base(2,3);...
    base(2,4) base(2,3) base(2,4)];

z = [pic(3)    pic(3)    pic(3);...
    base(3,1) base(3,2) base(3,3);...
    base(3,4) base(3,3) base(3,4)];

if(strcmp(refresh_fig,'no_refresh'))
    h(1:3) = fill3(x,y,z,color);
    hold on;
else
    set(h(1),'XData',x(:,1),'YData',y(:,1),'ZData',z(:,1));
    set(h(2),'XData',x(:,2),'YData',y(:,2),'ZData',z(:,2));
    set(h(3),'XData',x(:,3),'YData',y(:,3),'ZData',z(:,3));
end

x = [pic(1)    ; ...
    base(1,1) ;...
    base(1,2) ];

y = [pic(2)    ;...
    base(2,1) ;...
    base(2,2) ];

z = [pic(3)    ;...
    base(3,1) ;...
    base(3,2) ];


if(strcmp(refresh_fig,'no_refresh'))
    h(4) = fill3(x,y,z,'r');
    hold off;
else
    set(h(4),'XData',x,'YData',y,'ZData',z);
end


% x = [pic(1)    pic(1)    pic(1)    pic(1); ...
%      base(1,1) base(1,1) base(1,2) base(1,3);...
%      base(1,2) base(1,4) base(1,3) base(1,4)];
%
% y = [pic(2)    pic(2)    pic(2)    pic(2);...
%      base(2,1) base(2,1) base(2,2) base(2,3);...
%      base(2,2) base(2,4) base(2,3) base(2,4)];
%
% z = [pic(3)    pic(3)    pic(3)    pic(3);...
%      base(3,1) base(3,1) base(3,2) base(3,3);...
%      base(3,2) base(3,4) base(3,3) base(3,4)];
%
% fill3(x,y,z,'r');
