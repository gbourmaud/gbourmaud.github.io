function plotError(TrajEst,TrajTrue,legends,color)

nbPos = length(TrajEst);
X = zeros(6,nbPos);

for i = 1:nbPos
    X(1:3,i) =  logSO3(invSO3(TrajEst{i}.C.R)*TrajTrue{i}.C.R).^2;
    X(4:6,i) =  (TrajEst{i}.C.T - TrajTrue{i}.C.T).^2;
end

subplot(321);
hold on;
plot(1:nbPos,X(1,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Rx');
subplot(323);
hold on;
plot(1:nbPos,X(2,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Ry');
subplot(325);
hold on;
plot(1:nbPos,X(3,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Rz');


subplot(322);
hold on;
plot(1:nbPos,X(4,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Tx');
subplot(324);
hold on;
plot(1:nbPos,X(5,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Ty');
subplot(326);
hold on;
plot(1:nbPos,X(6,:),color);
oldleg = get(legend);
if(~isempty(oldleg))
    legend(oldleg.String,legends);
else
    legend(legends);
end
title('Tz');




