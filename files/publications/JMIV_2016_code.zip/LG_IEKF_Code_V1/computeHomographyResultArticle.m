%% Setup
clear;
close all;
clc;
[pathstr, ~, ~] = fileparts(mfilename('fullpath'));
cd(pathstr);
addpath(genpath('.'));

dbstop if error;
%dbstop if warning;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
%% load Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
load('dataHomographyArticle/dataRelHomography.mat');
load('dataHomographyArticle/gtMatrix.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
%% plot GT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
figure,imagesc(2*(gt+gt') + (Gweight>0)),colormap('gray'),axis square;
xlabel('image number'); ylabel('image number');
title('gt');
drawnow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
%% Run global motion estimation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
sizeMatrixLieGroup = 3;
nbDoF = 8;
nbSTMin = 15;

thresh = 26.12*9;

minST = findMinimumSpanningTree(Gweight);
nbItMax = 100;
plotOn = 0;
[HigUs,inliersUs] = LG_IEKF_GlobalMotion(minST,Gweight,Hij,cov_ij_i,sizeMatrixLieGroup,nbDoF,@invSL3,@logSL3,@AdSL3,@expSL3,nbItMax,thresh,plotOn);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
%% plot inliers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
figure,imagesc(2*(inliersUs+inliersUs') + (Gweight>0)),title('inlier us'),colormap('gray'),axis square;
xlabel('image number'); ylabel('image number');
drawnow;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
%% Build Mosaic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ù
load('dataHomographyArticle/imnames.mat');
tailleOutputImPix = 600;%3000;%300;%1500;

HggnewUs = inv(averageSL3(HigUs));

nbIm = length(HigUs);
outUs = {};


for iii = 1:nbIm
    imFullFile = imFullfileNames{keyframeIds(iii)};
    im = imread(imFullFile);
    
    %Hgi = inv(Hig{iii}*inv(Hig{1}));
    HgiUs = inv(HigUs{iii}*HggnewUs);
    T1 = maketform('projective',HgiUs');
    outUs{iii}=findbounds(T1, [1 1; size(im,2) size(im,1)]);
    
    
end

outUs = mergebounds(outUs);



for iii = 1:nbIm
    iii
    imFullFile = imFullfileNames{keyframeIds(iii)};
    im = imread(imFullFile);
    
    HgiUs = inv(HigUs{iii}*HggnewUs);
    
    
    
    if(~exist('im1RectNewUs','var'))
        bool = true;
    end
    
    tailleImUs = max(abs(outUs(1,1)-outUs(2,1)),abs(outUs(1,2)-outUs(2,2)));

    
    %if (tailleIm>tailleOutputImPix)
    xyscaleUs = tailleImUs/tailleOutputImPix;

    
    %end
    [im1RectNewUs] = ImageRectification(im, HgiUs, outUs,xyscaleUs);

    
    if(bool)
        im1RectUs = im1RectNewUs;

        
        maskUs = double((im1RectNewUs(:,:,1)+im1RectNewUs(:,:,2)+im1RectNewUs(:,:,3))>0);

        
        bool = false;
    else
        if(isequal(size(im1RectNewUs),size(im1RectUs)))
            im1RectUs = im1RectNewUs + im1RectUs;

            
            maskUs = maskUs + double((im1RectNewUs(:,:,1)+im1RectNewUs(:,:,2)+im1RectNewUs(:,:,3))>0);

            
        else
            disp('size problem');
        end
    end
    

end

maskUs = maskUs + (double(maskUs==0));


% figure,imagesc(mask), colorbar;
% title('mask');

imFinalUs(:,:,1) = im1RectUs(:,:,1)./maskUs;
imFinalUs(:,:,2) = im1RectUs(:,:,2)./maskUs;
imFinalUs(:,:,3) = im1RectUs(:,:,3)./maskUs;
figure,imshow(imFinalUs);
title('final result Us');



