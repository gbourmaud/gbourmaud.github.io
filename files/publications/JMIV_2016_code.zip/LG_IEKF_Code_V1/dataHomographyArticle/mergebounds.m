function out = mergebounds(out)

nbIm = length(out);
outStack = [];
for i = 1:nbIm
    
    outStack = [outStack; out{i}];
end
out = [min(outStack(1:2:end,:),[],1); max(outStack(2:2:end,:),[],1)];
end