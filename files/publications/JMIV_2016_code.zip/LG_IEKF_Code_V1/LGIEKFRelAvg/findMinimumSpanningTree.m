function [ST] = findMinimumSpanningTree(G)
%G graph d'adjacence de poids

if(~isequal(G,G'))
    error('G has to be symmetric while Tij is upper triangular');
end

nbNode = size(G,1);

ST = zeros(nbNode-1,2);
%spanning tree
S = zeros(nbNode,1);

%start from the edge with the biggest weight
G(G==0) = Inf;
[valRow,indRow] = min(G);
[valCol,indCol] = min(valRow);

S(indCol) = 1;
S(indRow(indCol)) = 1;

count = 1;
ST(count,1) = indCol;
ST(count,2) = indRow(indCol);


while sum(S) < nbNode;%spanning tree
    
    
    
    %% prolonge le spanning tree
    %Choose camera with many matches parmi les caméras encore libres
    %rattachables au MST en un coup (S*(1-S)') et valides (G)
    [k,l,W] = find(S*(1-S)'.*G);
    if isempty(W)
        break;
    end
    
    count = count + 1;
    [val,ind] = min(W);
    if(val == Inf)
        error('disconnected Graph');
    end
    %     %         prob = rand;
    %     %         ind = find(cumsum(W.^5)./sum(W.^5) >= prob);
    %     %         ind = ind(1);
    %     temp = randperm(length(W));
    %     ind = temp(1);
    S(l(ind)) = 1;
    ST(count,1) = k(ind);
    ST(count,2) = l(ind);
    
    
end

ST = ST(1:count,:);
end






