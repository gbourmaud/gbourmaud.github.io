function [Tig,inliers] = LG_IEKF_GlobalMotion(ST,G,Tij,cov_ij_i,sizeMatrixLieGroup,nbDoF,invG, logG, AdG, expG,nbItMax,thresh,plotOn)
%G graph d'adjacence de poids

%G = double(G>0);
if(~isequal(G,G'))
    error('G has to be symmetric while Tij is upper triangular');
end

nbNode = size(Tij,1);

%spanning tree
Tig = cell(1,nbNode);
Tig{ST(1,1)} = eye(sizeMatrixLieGroup);

inliers = zeros(nbNode);
nbNode = size(Tij,1);
%

cov_ig_i =zeros(nbNode*nbDoF);
inverseIndexPose = [];
indexPose = [];

for iii = 1:nbNode-1
    
    k = ST(iii,1);
    l = ST(iii,2);
    if(k<l)
        Tlk_temp = invG(Tij{k,l});
        cov_kl_k_temp = cov_ij_i{k,l};
        
        cov_lk_l_temp = AdG(Tlk_temp) * cov_kl_k_temp * (AdG(Tlk_temp)');
    elseif(k>l)
        Tlk_temp = Tij{l,k};
        cov_lk_l_temp = cov_ij_i{l,k};
        
        
    end
    
    %% Propagation
    
    inliers(min(k,l),max(k,l)) = 1;
    currentPoseInd = l;

    [Tig,cov_ig_i,inverseIndexPose,indexPose] = propagationIEKF(Tig,cov_ig_i,Tlk_temp,cov_lk_l_temp,nbDoF,expG,logG,invG,AdG,k,l,inverseIndexPose,indexPose);
    

    %
    [inliers, indLoopclos] = seekInliers(Tig,cov_ig_i,Tij,cov_ij_i,inverseIndexPose,G,currentPoseInd,inliers,invG,logG,AdG,nbDoF,thresh);
    
    figure(2),imagesc(inliers),drawnow;
    
    %% Update
    %
    if(~isempty(indLoopclos))
        [Tig,cov_ig_i,inverseIndexPose,indexPose] = updateIEKF(Tig,cov_ig_i,Tij,cov_ij_i,indLoopclos,nbDoF,expG,logG,invG,AdG,inverseIndexPose,indexPose,nbItMax,plotOn);

    end
    
end

cond = true;%include missed inliers and refine

while(cond)
    
    [inliers, indLoopclos] = seekInliersFinal(Tig,cov_ig_i,Tij,cov_ij_i,inverseIndexPose,G,inliers,invG,logG,AdG,nbDoF,thresh);
    if(~isempty(indLoopclos))
        [Tig,cov_ig_i,inverseIndexPose,indexPose] = updateIEKF(Tig,cov_ig_i,Tij,cov_ij_i,indLoopclos,nbDoF,expG,logG,invG,AdG,inverseIndexPose,indexPose,nbItMax,plotOn);
    else
        cond = false;
    end
    figure(2),imagesc(inliers),drawnow;
    
end
end


function [Tig,cov_ig_i,inverseIndexPose,indexPose] = propagationIEKF(Tig,cov_ig_i,Tlk_temp,cov_lk_l_temp,nbDoF,expG,logG,invG,AdG,k,l,inverseIndexPose,indexPose)

if(isempty(indexPose))
    Tig{l} = Tlk_temp*Tig{k};
    
    [~,indexPose] = find(~cellfun(@isempty,Tig));
    
    nbPoseTot = length(Tig);
    inverseIndexPose = zeros(1,nbPoseTot);
    inverseIndexPose(indexPose) = 1:length(indexPose);
    
    invIndk = inverseIndexPose(k);
    invIndl = inverseIndexPose(l);
    cov_ig_i(1+(invIndk-1)*nbDoF:invIndk*nbDoF,1+(invIndk-1)*nbDoF:invIndk*nbDoF) = ...
        (1/4)*AdG(Tig{k}*invG(Tig{l}))*cov_lk_l_temp*(AdG(Tig{k}*invG(Tig{l}))');
    cov_ig_i(1+(invIndl-1)*nbDoF:invIndl*nbDoF,1+(invIndl-1)*nbDoF:invIndl*nbDoF) = ...
        (1/4)*cov_lk_l_temp;
    
    crosscorrkl = -(1/4)*AdG(Tig{k}*invG(Tig{l}))*cov_lk_l_temp;
    cov_ig_i(1+(invIndk-1)*nbDoF:invIndk*nbDoF,1+(invIndl-1)*nbDoF:invIndl*nbDoF) = crosscorrkl;
    
    cov_ig_i(1+(invIndl-1)*nbDoF:invIndl*nbDoF,1+(invIndk-1)*nbDoF:invIndk*nbDoF) = crosscorrkl';
    
else
    Tig{l} = Tlk_temp*Tig{k};
    nbPose = length(indexPose);
    indexPose(nbPose+1) = l;
    inverseIndexPose(l) = nbPose+1;
    
    invIndk = inverseIndexPose(k);
    invIndl = inverseIndexPose(l);
    
    AdGTlk_temp = AdG(Tlk_temp);
    covTempRow = AdGTlk_temp*cov_ig_i(1+(invIndk-1)*nbDoF:invIndk*nbDoF,:);
    covTempCol = cov_ig_i(:,1+(invIndk-1)*nbDoF:invIndk*nbDoF)*(AdGTlk_temp');
    
    cov_ig_i(1+(invIndl-1)*nbDoF:invIndl*nbDoF,:) = covTempRow;
    
    cov_ig_i(:,1+(invIndl-1)*nbDoF:invIndl*nbDoF) = covTempCol;
    
    
    cov_ig_i(1+(invIndl-1)*nbDoF:invIndl*nbDoF,1+(invIndl-1)*nbDoF:invIndl*nbDoF) = ...
        AdGTlk_temp*cov_ig_i(1+(invIndk-1)*nbDoF:invIndk*nbDoF,1+(invIndk-1)*nbDoF:invIndk*nbDoF)*(AdGTlk_temp') ...
        + cov_lk_l_temp;
    
    
end

cov_ig_i = (cov_ig_i+cov_ig_i')/2;
end

function [inliers,indLoopclos] = seekInliersFinal(Tig,cov_ig_i,Tij,cov_ij_i,inverseIndexPose,...
    G,inliers,invG,logG,AdG,nbDoF,thresh)
nbPose = length(Tig);

indLoopclos = [];
if(~isempty(inverseIndexPose))
    
    for ll = 1:nbPose
        currentPoseInd = ll;
        indLinkCurrentPose = find(G(currentPoseInd,:)>0);
        nbLink = length(indLinkCurrentPose);
        
        m = currentPoseInd;%i
        Tgm = invG(Tig{m});
        mIndCov = inverseIndexPose(m);
        
        cov_mg_m = cov_ig_i(1+(mIndCov-1)*nbDoF:mIndCov*nbDoF,1+(mIndCov-1)*nbDoF:mIndCov*nbDoF);
        
        for l = 1:nbLink
            k = indLinkCurrentPose(l);
            maxCurrentPoseIndK = max(currentPoseInd,k);
            minCurrentPoseIndK = min(currentPoseInd,k);
            if(inliers(minCurrentPoseIndK,maxCurrentPoseIndK)==0)
                if(~isempty(Tig{k}))
                    n = k;%j
                    Tng = Tig{n};
                    nIndCov = inverseIndexPose(n);
                    
                    cov_ng_n = cov_ig_i(1+(nIndCov-1)*nbDoF:nIndCov*nbDoF,1+(nIndCov-1)*nbDoF:nIndCov*nbDoF);
                    
                    crossCov_mn_m = cov_ig_i(1+(mIndCov-1)*nbDoF:mIndCov*nbDoF,1+(nIndCov-1)*nbDoF:nIndCov*nbDoF);
                    
                    if(m<n)
                        Tmn = Tij{m,n};
                        cov_mn_m = cov_ij_i{m,n};
                    else
                        Tnm = Tij{n,m};
                        cov_nm_n_temp = cov_ij_i{n,m};
                        
                        Tmn = invG(Tnm);
                        cov_mn_m = AdG(Tmn)*cov_nm_n_temp*(AdG(Tmn)');
                        
                    end
                    
                    
                    
                    
                    
                    bool = isInlier(Tgm,cov_mg_m,Tng,cov_ng_n, crossCov_mn_m, Tmn, cov_mn_m,invG, AdG, logG,thresh);
                    
                    if(bool)
                        inliers(minCurrentPoseIndK,maxCurrentPoseIndK) = 1;
                        indLoopclos = [indLoopclos; [minCurrentPoseIndK,maxCurrentPoseIndK]];
                        
                    end
                end
            end
        end
    end
end
end

function [inliers,indLoopclos] = seekInliers(Tig,cov_ig_i,Tij,cov_ij_i,inverseIndexPose,...
    G,currentPoseInd,inliers,invG,logG,AdG,nbDoF,thresh)


indLoopclos = [];
if(~isempty(inverseIndexPose))
    indLinkCurrentPose = find(G(currentPoseInd,:)>0);
    nbLink = length(indLinkCurrentPose);
    
    m = currentPoseInd;%i
    Tgm = invG(Tig{m});
    mIndCov = inverseIndexPose(m);
    
    cov_mg_m = cov_ig_i(1+(mIndCov-1)*nbDoF:mIndCov*nbDoF,1+(mIndCov-1)*nbDoF:mIndCov*nbDoF);
    
    for l = 1:nbLink
        k = indLinkCurrentPose(l);
        maxCurrentPoseIndK = max(currentPoseInd,k);
        minCurrentPoseIndK = min(currentPoseInd,k);
        if(inliers(minCurrentPoseIndK,maxCurrentPoseIndK)==0)
            if(~isempty(Tig{k}))
                n = k;%j
                Tng = Tig{n};
                nIndCov = inverseIndexPose(n);
                
                cov_ng_n = cov_ig_i(1+(nIndCov-1)*nbDoF:nIndCov*nbDoF,1+(nIndCov-1)*nbDoF:nIndCov*nbDoF);
                
                crossCov_mn_m = cov_ig_i(1+(mIndCov-1)*nbDoF:mIndCov*nbDoF,1+(nIndCov-1)*nbDoF:nIndCov*nbDoF);
                
                if(m<n)
                    Tmn = Tij{m,n};
                    cov_mn_m = cov_ij_i{m,n};
                else
                    Tnm = Tij{n,m};
                    cov_nm_n_temp = cov_ij_i{n,m};
                    
                    Tmn = invG(Tnm);
                    cov_mn_m = AdG(Tmn)*cov_nm_n_temp*(AdG(Tmn)');
                    
                end
                
                
                
                
                
                bool = isInlier(Tgm,cov_mg_m,Tng,cov_ng_n, crossCov_mn_m, Tmn, cov_mn_m,invG, AdG, logG,thresh);
                
                if(bool)
                    inliers(minCurrentPoseIndK,maxCurrentPoseIndK) = 1;
                    indLoopclos = [indLoopclos; [minCurrentPoseIndK,maxCurrentPoseIndK]];
                    
                end
            end
        end
    end
end
end

function bool = isInlier(Tgi,cov_ig_i,Tjg,cov_jg_j, crossCov_ij_i, Tij, cov_ij_i,invG, AdG, logG,thresh)

bool = false;

err = Tij*Tjg*Tgi;


[TigTgj,errorFlag] = invG(Tjg*Tgi);
if(exist('errorFlag','var'))
    if(errorFlag == 1)
        return;
    end
end

Adij = AdG(TigTgj);



[errLie,errorFlag] = logG(err);

if(exist('errorFlag','var'))
    if(errorFlag == 1)
        return;
    end
end

%errLie'*errLie
covRes = cov_ig_i - crossCov_ij_i*(Adij') - Adij*(crossCov_ij_i') + Adij*cov_jg_j*(Adij') + cov_ij_i;
covRes = (covRes + covRes')/2;
% res = errLie'*inv(covRes)*errLie
%
% covResBis = cov_ig_i + Adij*cov_jg_j*(Adij') + cov_ij_i;
%
% resBis = errLie'*inv(covResBis)*errLie
%
% covResQuad = cov_ig_i - (crossCov_ij_i')*(Adij') - Adij*(crossCov_ij_i) + Adij*cov_jg_j*(Adij') + cov_ij_i;
%
% resQuad = errLie'*inv(covResQuad)*errLie

%covRes = cov_ig_i - (crossCov_ij_i')*(Adij') - Adij*(crossCov_ij_i) + Adij*cov_jg_j*(Adij') + cov_ij_i;
[U,S,V] = svd(covRes);
s = diag(S);
sinv = 1./s;
sqrtsinv = sqrt(sinv);
temp = errLie'*((U+V)/2)*diag(sqrtsinv);
% invCovRes = U*diag(sinv)*(V');
% invCovRes = (invCovRes+invCovRes')/2;
% res = errLie'*invCovRes*errLie;

res = temp*temp';
if(res<0)
    warning('should be positive');
    return;
end
if(res<thresh)
    
    bool = true;
end
end

function [Tig,cov_ig_i,inverseIndexPose,indexPose] = updateIEKF(Tig,cov_ig_i,Tij,cov_ij_i,indLoopclos,nbDoF,expG,logG,invG,AdG,inverseIndexPose,indexPose,nbItMax,plotOn)

thresh = 1e-12;
nbMes = size(indLoopclos,1);

for i = 1:nbMes
    indLoopclosTemp = indLoopclos(i,:);
    nbMesTemp = 1;
    
    [~,indPose] = find(~cellfun(@isempty,Tig));
    nbPose = length(indPose);
    cond = true;
    
    TigInit = Tig;
    TigPrec = Tig;
    
    C = cov_ig_i(1:nbPose*nbDoF,1:nbPose*nbDoF);
    
    deltaPrec = zeros(nbPose*nbDoF,1);
    [DPrec, Sigma] = computeJacAndCovMes(TigPrec,cov_ij_i,nbDoF,nbPose,nbMesTemp,inverseIndexPose,indLoopclosTemp,AdG,invG);
    [innovPrec,errPrec] = computeInnov(Tij,TigPrec,DPrec,deltaPrec,nbMesTemp,indLoopclosTemp,invG,logG,nbDoF);
    resErrPrec = norm(errPrec);
    resInnovPrec = norm(innovPrec);
    
    nbIt = 0;
    
    while cond
        nbIt = nbIt + 1
        
        covTemp = DPrec*C*(DPrec') + Sigma;
        covTemp = (covTemp+covTemp')/2;
        [U,S,V] = svd(covTemp);
        s = diag(S);
        sinv = 1./s;
        invCov = U*diag(sinv)*(V');
        invCov = (invCov+invCov')/2;
        K = C*(DPrec')*invCov;
        
        
        delta = K*innovPrec;
        TigNew = updateVar(delta,TigInit,indexPose,expG,nbDoF,nbPose);
        
        %norm(delta-deltaPrec)
        %norm(innov-innovPrec)
        %norm(delta-deltaPrec)
        %norm(innov-innovPrec)
        %norm(innov)-norm(innovPrec)
        %if((norm(delta-deltaPrec)<thresh && norm(innov-innovPrec)<thresh) || nbIt >= nbItMax)
        
        [DNew, Sigma] = computeJacAndCovMes(TigNew,cov_ij_i,nbDoF,nbPose,nbMesTemp,inverseIndexPose,indLoopclosTemp,AdG,invG);
        [innovNew,errNew] = computeInnov(Tij,TigNew,DNew,delta,nbMesTemp,indLoopclosTemp,invG,logG,nbDoF);
        resErrNew = norm(errNew);
        resInnovNew = norm(innovNew);
        
        if(plotOn)
        
        sceneSize = computeScaleSim3(TigNew);
        figure(3);
        clf(3);
        PlotPointScene(TigNew);
        hold on;
        %scatter3(p3D(1,:),p3D(2,:),p3D(3,:));
        axis equal;
        grid on;
        cameratoolbar;
        drawnow;
        
        end
        
        
        if(norm(delta-deltaPrec)<thresh || (resErrNew > resErrPrec &&  resInnovNew > resInnovPrec))
            
            if(nbIt==1)%aucune itération n'a été effectué
                return;
            else
                
                CNew = (eye(nbPose*nbDoF)-K*DPrec)*C;
                
                CNew = (CNew+CNew')/2;
                cov_ig_i(1:nbPose*nbDoF,1:nbPose*nbDoF) = CNew;
                Tig = TigPrec;
                
                return;
            end
        elseif(nbIt >= nbItMax)
            
            CNew = (eye(nbPose*nbDoF)-K*DNew)*C;
            
            CNew = (CNew+CNew')/2;
            cov_ig_i(1:nbPose*nbDoF,1:nbPose*nbDoF) = CNew;
            Tig = TigNew;
            
            return;
        end
        
        deltaPrec = delta;
        innovPrec = innovNew;
        TigPrec = TigNew;
        resErrPrec = resErrNew;
        resInnovPrec = resInnovNew;
        
        DPrec = DNew;
        
    end
end

end





function [innov,res] = computeInnov(Tij,Tig,D,deltaPrec,nbMes,ij,invG,logG,nbDoF)
res = zeros(nbDoF*nbMes,1);
for k = 1:nbMes
    m = ij(k,1);
    n = ij(k,2);
    
    res(1 + (k-1)*nbDoF : k*nbDoF) = logG( Tij{m,n} * Tig{n} * invG(Tig{m}));
    
end

innov = res + D*deltaPrec;
end

function Tig = updateVar(delta,Tig,indexPose,expG,nbDoF,nbPose)

temp = expG(delta(1:nbDoF)) * Tig{indexPose(1)} ;
invT1g = inv(temp);

%Tig(indexPose) = cellfun(@(x) x*invT1g,Tig(indexPose),'UniformOutput',0);

for k = 2:nbPose
    Tig{indexPose(k)} = expG(delta(1+(k-1)*nbDoF:k*nbDoF)) * Tig{indexPose(k)} * invT1g ;
end

Tig{indexPose(1)} = eye(size(temp,1));

end

function [D,Sigma] = computeJacAndCovMes(Tig,cov_ij_i,nbDoF,nbPose,nbMes,inverseIndexPose,ij,AdG,invG)

D = zeros(nbMes*nbDoF,nbPose*nbDoF);
Sigma = zeros(nbDoF*nbMes);

IdNbDoF = eye(nbDoF);
for k = 1:nbMes
    m = ij(k,1);
    n = ij(k,2);
    idNodei = inverseIndexPose(m);%i = row
    idNodej = inverseIndexPose(n);%j = col
    
    D(1+(k-1)*nbDoF:k*nbDoF,1+(idNodei-1)*nbDoF:idNodei*nbDoF) = IdNbDoF;
    
    D(1+(k-1)*nbDoF:k*nbDoF,1+(idNodej-1)*nbDoF:idNodej*nbDoF) = -AdG(Tig{m}*invG(Tig{n}));
    
    cov_mn_m = cov_ij_i{m,n};
    
    %sigInvTemp = inv(cov_mn_m);%cov
    Sigma(1+(k-1)*nbDoF:k*nbDoF,1+(k-1)*nbDoF:k*nbDoF) = cov_mn_m;
    
end


end



