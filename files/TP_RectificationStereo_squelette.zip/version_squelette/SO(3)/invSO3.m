function [Rinv,errorFlag] = invSO3(R)

errorFlag = 0;
Rinv = R';
