function P = getRelativeMotionFromFandK(K1, K2, Fund, X1, X2)

E = K2'*Fund*K1;

% Ensure we can convert it to rotation and translation by forcing both
% non zero eigenvalues to be equal (the average of both)
[U,S,V] = svd(E);
m = (S(1,1)+S(2,2))/2;
E = U*[m,0,0;0,m,0;0,0,0]*V';

% Obtain the second camera matrices
P = getCameraMatrixHorn(E);
E_temp = zeros(3,3,4);
E_temp(:,:,1) = E;
E_temp(:,:,2) = E;
E_temp(:,:,3) = E;
E_temp(:,:,4) = E;
P = getCorrectCameraMatrix(P, E_temp, K1, K2,[X1;X2]);