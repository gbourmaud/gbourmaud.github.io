function [R1,R2] = rectify(R1g,T1g,R2g,T2g)

% RECTIFY: compute rectification matrices

% optical centers (unchanged)
c1 = - R1g'*T1g;
c2 = - R2g'*T2g;

% new x axis (= direction of the baseline)
v1 = (c1-c2);
% new y axes (orthogonal to new x and old z)
v2 = cross(R1g(3,:)',v1);
% new z axes (orthogonal to baseline and y)
v3 = cross(v1,v2);

% new extrinsic parameters
Rng = [v1'/norm(v1)
    v2'/norm(v2)
    v3'/norm(v3)];
% translation is left unchanged

% rectifying image transformation
R1 = Rng*R1g';
R2 = Rng*R2g';

% ------------------------
