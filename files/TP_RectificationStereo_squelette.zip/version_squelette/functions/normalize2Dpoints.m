function [p_norm_hom, T] = normalize2Dpoints(p_hom)

% If the points are not homogeneous
if(size(p_hom,1)==2)
    Xt = ones(3,size(p_hom,2));
    Xt(1:2,:) = p_hom;
    p_hom = Xt;
end


% Normalize with the centroid
c = mean(p_hom(1:2,:)')';
X_centered = [1,   0,     -c(1);
    0,    1, -c(2);
    0,    0,       1]*p_hom;

% Compute the mean distance
meandistance = mean(sqrt(X_centered(1,:).^2+X_centered(2,:).^2));

% Compute the scale factor
scale = sqrt(2)/meandistance;

% Transformation matrix
T = [scale,   0,     -scale*c(1);
    0,    scale, -scale*c(2);
    0,    0,       1];

% Normalize points
p_norm_hom = T*p_hom;
