function R = sphere2MatRot(x)

ref = [0;0;1];
a = cross(ref,x);

if(x(3)<0)
    
    norm2apply = pi-asin(norm(a));
else
    norm2apply = asin(norm(a));
end
a = a/norm(a);
a = a*norm2apply;
R = expSO3(a);

% if(sum((abs(R*ref-x))>(1000000*eps)) ~= 0)
%     error('bad function sphere2matrot');
% end