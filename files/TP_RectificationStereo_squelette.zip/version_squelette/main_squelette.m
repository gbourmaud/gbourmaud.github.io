clear;
close all;
clc;
dbstop if error;
addpath(genpath('.'));

%% LOAD CAMERA CALIBRATION & IMAGES
im1=double(imread('./data/1.png'))/255;
im2=double(imread('./data/3.png'))/255;

K = [535.4 0 320.1;
    0 539.2 247.6;
    0 0 1];

%% SIFT & MATCHING

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%extract SIFT from both images (using vl_sift)
%TODO
%find matches (using vl_ubcmatch)
%TODO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,
plotmatches(im1,im2,f1,f2,matches,'interactive',0);

i1 = matches(1,:)';
i2 = matches(2,:)';
numOfMatches = size(i1,1);
p1_hom = ones(3,numOfMatches);
p2_hom = ones(3,numOfMatches);
p1_hom(1:2,:) = f1(1:2,i1);
p2_hom(1:2,:) = f2(1:2,i2);

%% RANSAC & FUNDAMENTAL MATRIX ESTIMATION

NbItRansac = 500;
ThreshRansac = 1.5; %in pixels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%implement a function that performs RANSAC using the eight point algorithm
%TODO [F, inliers, nbInliers] = ransacF(X1,X2,NbItRansac,ThreshRansac);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure,
plotmatches(im1,im2,f1,f2,matches(:,inliers),'interactive',0);

vgg_gui_F(im1, im2, F');

p1inliers_hom = p1_hom(:,inliers);
p2inliers_hom = p2_hom(:,inliers);

%% NON LINEAR REFINEMENT OF THE ESSENTIAL MATRIX

[E, R21, T21] = refineEssentialMatrix(K,F,p1inliers_hom,p2inliers_hom);

F_new = inv(K')*E*inv(K);

vgg_gui_F(im1, im2, F_new');

%% COMPUTE HOMOGRAPHY RECTIFICATION

[Hn1, Hn2] = computeHomographyRectification(K, R21, T21);

%% IMAGE RECTIFICATION

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%implement a function that applies an homography to an image
%TODO [im1Rect,im2Rect] = rectifyImages(im1, im2, Hn1, Hn2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vgg_gui_F(im1Rect, im2Rect, vl_hat([1 0 0]));
